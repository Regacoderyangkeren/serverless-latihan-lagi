<script setup>
import NavbarThemeSwitcher from "@/layouts/components/NavbarThemeSwitcher.vue";
</script>

<template>
   <v-card class="px-5 mx-3 py-2 rounded-lg">
      <div class="d-flex flex-column">
         <span class="text-h4 font-weight-bold mt-2 mb-1">[SW] SoundWave Production</span>
         <span class="text-sm text-justify">
            We're your premier music promoter, dedicated to unforgettable concert experiences. With decades of experience, we're the top choice for music lovers seeking remarkable moments. Explore our user-friendly website for concert info, quick ticket purchases, and reliable customer service. Join us in celebrating the power of music.
         </span>
      </div>
   </v-card>
</template>