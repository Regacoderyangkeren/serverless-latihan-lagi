<template>
   <div class="d-flex flex-row align-center justify-center">
      <!-- 👉 Footer: left content -->
      <span class="d-flex align-center text-caption mr-2">
         Build With
         <VIcon icon="tabler-heart" color="error" size=".85rem" class="mx-1" />
         For
         <a
            href="https://smk.pusatprestasinasional.kemdikbud.go.id/lks/"
            target="_blank"
            rel="noopener noreferrer"
            class="text-primary ms-1"
            ><span class="font-weight-bold">LKS Nasional 2023</span>
         </a>
      </span>
   </div>
</template>
